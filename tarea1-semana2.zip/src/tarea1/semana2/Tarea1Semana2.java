/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tarea1.semana2;

/**
 *
 * @author ariel.montoya
 */
import java.util.Scanner;
public class Tarea1Semana2 {


    public static void main(String[] args) {
    char operador;
    Double n1, n2, resultado;

    Scanner input = new Scanner(System.in);

    System.out.println("Ingresa unos de los siguientes operadores: +, -, *, /");
    operador = input.next().charAt(0);

    System.out.println("Ingrese el primero numero");
    n1 = input.nextDouble();

    System.out.println("Ingrese el segundo numero");
    n2 = input.nextDouble();

    switch (operador) {

      case '+':
        resultado = n1 + n2;
        System.out.println(n1 + " + " + n2 + " = " + resultado);
        break;

      case '-':
        resultado = n1 - n2;
        System.out.println(n1 + " - " + n2 + " = " + resultado);
        break;

      case '*':
        resultado = n1 * n2;
        System.out.println(n1 + " * " + n2 + " = " + resultado);
        break;

      case '/':
        resultado = n1 / n2;
        System.out.println(n1 + " / " + n2 + " = " + resultado);
        break;

      default:
        System.out.println("Error!!! Operador invalido.");
        break;
    }

    input.close();
  }
}
